#include "InvestmentCalculator.h"

int main() {
    InvestmentCalculator app;
    app.Run();
    return 0;
}
